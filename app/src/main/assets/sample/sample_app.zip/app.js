(function () {
  var out = document.getElementById('out');
  function show(msg) {
    if (typeof msg === 'object') {
      try { msg = JSON.stringify(msg, null, 2); } catch (e) { msg = String(msg); }
    }
    out.textContent = String(msg);
  }
  function run(factory) {
    Promise.resolve().then(factory).then(show, function (e) {
      show('错误: ' + (e && e.message ? e.message : e));
    });
  }
  function waitForBridge(maxMs) {
    maxMs = maxMs || 3000;
    return new Promise(function (resolve, reject) {
      var t0 = Date.now();
      (function check() {
        if (window.MiniApp && window.__MiniAppBridge) return resolve();
        if (Date.now() - t0 > maxMs) return reject(new Error('bridge not ready'));
        setTimeout(check, 50);
      })();
    });
  }
  function ask(title, def) {
    var v = prompt(title, def);
    return (v == null) ? null : v;
  }
  function b64ToText(b64) {
    var bin = atob(b64);
    try { return decodeURIComponent(escape(bin)); } catch (e) { return null; }
  }

  var wasm = null;
  function ensureWasm() {
    if (wasm) return Promise.resolve(wasm);
    return MiniApp.wasm.instantiate('app/sample.wasm').then(function (inst) { wasm = inst; return inst; });
  }

  var actions = {
    // ---- 应用与系统 ----
    info: function () { return MiniApp.info(); },
    system: function () { return MiniApp.system(); },

    // ---- 沙箱文件 ----
    write: function () {
      return MiniApp.fs.write('data/test.txt', '你好，沙箱 ' + new Date().toISOString())
        .then(function () { return MiniApp.toast('已写入'); })
        .then(function () { return '已写入 data/test.txt'; });
    },
    read: function () { return MiniApp.fs.read('data/test.txt'); },
    list: function () { return MiniApp.fs.list('data'); },
    stat: function () { return MiniApp.fs.stat('data/test.txt'); },

    // ---- 外部文件（需 fs.external）----
    listExt: function () {
      var dir = ask('要列出的内部储存目录', '/storage/emulated/0');
      if (dir == null) return '已取消';
      return MiniApp.fs.listExternal(dir);
    },
    readExt: function () {
      var p = ask('要读取的外部文件（base64 方式）', '/storage/emulated/0/Documents/test.txt');
      if (p == null) return '已取消';
      return MiniApp.fs.readExternalFile(p).then(function (b64) {
        var text = b64ToText(b64);
        return '读取 ' + b64.length + ' 字符 base64\n' +
          (text != null ? '文本内容:\n' + text.slice(0, 400) : '（二进制内容，已省略）');
      });
    },
    openExt: function () {
      var p = ask('要流式读取的外部文件（授权 URL + fetch）', '/storage/emulated/0/Documents/test.txt');
      if (p == null) return '已取消';
      return MiniApp.fs.openExternalFile(p).then(function (url) {
        return fetch(url).then(function (r) { return r.text(); }).then(function (body) {
          return '授权 URL: ' + url + '\nHTTP 流式读取 ' + body.length + ' 字符\n\n' +
            body.slice(0, 400) + (body.length > 400 ? '…' : '');
        });
      });
    },

    // ---- WASM ----
    'wasm-add': function () {
      return ensureWasm().then(function (inst) { return 'WASM add(2,3) = ' + inst.exports.add(2, 3); });
    },
    'wasm-fib': function () {
      return ensureWasm().then(function (inst) { return 'WASM fib(15) = ' + inst.exports.fib(15); });
    },

    // ---- 网络（需 net）----
    net: function () {
      return MiniApp.net.get('https://example.com').then(function (r) {
        return 'HTTP ' + r.status + '（body ' + (r.body ? r.body.length : 0) + ' 字符）';
      });
    },

    // ---- 剪贴板（需 clipboard）----
    'cb-read': function () {
      return MiniApp.clipboard.read().then(function (t) { return '剪贴板: ' + t; });
    },
    'cb-write': function () {
      var t = ask('写入剪贴板的内容', '蜗壳示例 ' + new Date().toLocaleTimeString());
      if (t == null) return '已取消';
      return MiniApp.clipboard.write(t).then(function () { return '已写入剪贴板: ' + t; });
    },

    // ---- 通知（需 notification）----
    notify: function () {
      return MiniApp.notification.show('蜗壳示例', '这条通知来自示例小程序')
        .then(function () { return '已发送通知'; });
    },
    'notify-cancel': function () {
      return MiniApp.notification.cancel().then(function () { return '已取消通知'; });
    },

    // ---- 网络存储（需 storage 权限 + 已配置 WebDAV）----
    'storage-list': function () {
      return MiniApp.storage.list('').then(function (r) { return r; });
    },

    // ---- Dex 隔离进程执行（无需权限）----
    'dex-info': function () {
      return MiniApp.dex.run({
        dex: 'app/demo.dex', className: 'com.miniapp.demo.Demo',
        params: { action: 'info' }
      });
    },
    'dex-fib': function () {
      return MiniApp.dex.run({
        dex: 'app/demo.dex', className: 'com.miniapp.demo.Demo',
        params: { action: 'fib', n: 30 }
      });
    },
    'dex-reverse': function () {
      var s = ask('要反转的字符串（交给隔离进程处理）', '蜗壳 Dex 隔离进程');
      if (s == null) return '已取消';
      return MiniApp.dex.run({
        dex: 'app/demo.dex', className: 'com.miniapp.demo.Demo',
        params: { action: 'reverse', s: s }
      });
    },

    // ---- 设备控制 ----
    vibrate: function () {
      return MiniApp.sys.vibrate(300).then(function () { return '已震动 300ms'; });
    },
    flashlight: function () {
      return MiniApp.sys.flashlight(true).then(function () { return '手电筒已打开'; });
    },
    'flashlight-off': function () {
      return MiniApp.sys.flashlight(false).then(function () { return '手电筒已关闭'; });
    },
    orientation: function () {
      return MiniApp.sys.setOrientation('landscape').then(function () { return '已切换横屏'; });
    },
    portrait: function () {
      return MiniApp.sys.setOrientation('portrait').then(function () { return '已切回竖屏'; });
    },
    statusbar: function () {
      return MiniApp.sys.setStatusBarColor('#2563EB').then(function () { return '状态栏颜色已设为 #2563EB'; });
    },
    selection: function () {
      return MiniApp.sys.setTextSelection(true).then(function () { return '已允许长按文本选择'; });
    },

    // ---- 权限 ----
    perm: function () {
      return MiniApp.permission.request('net').then(function (ok) { return 'net 授权: ' + (ok ? '是' : '否'); });
    }
  };

  document.querySelector('main').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    var act = b.getAttribute('data-act');
    if (actions[act]) run(actions[act]);
  });

  waitForBridge().then(function () { run(actions.info); }, function (e) { show('桥未就绪: ' + e.message); });
})();
